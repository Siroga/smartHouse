-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 12, 2018 at 11:11 AM
-- Server version: 5.6.37
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_house_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE `devices` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `name`, `ip`, `hash`, `group_id`) VALUES
(1, 'Bed room temp', '192.168.0.51', NULL, 1),
(2, 'boiler', '192.168.2.10', NULL, 4),
(3, 'Bed room servo', '192.168.2.13', NULL, 1),
(4, 'out temp', '192.168.2.10', NULL, 4),
(5, 'Children room temp', '192.168.0.11', NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`) VALUES
(1, 'bedroom'),
(2, 'children room'),
(3, 'kitchen'),
(4, 'boiler');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `status` int(11) DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `status`, `createdAt`, `device_id`) VALUES
(1, 1, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `day` int(11) DEFAULT NULL,
  `startTime` time DEFAULT NULL,
  `endTime` time DEFAULT NULL,
  `value` float DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `day`, `startTime`, `endTime`, `value`, `group_id`) VALUES
(1, 1, '00:00:00', '06:00:00', 20, 1),
(2, 1, '06:30:00', '08:00:00', 21, 1),
(3, 1, '08:00:00', '16:30:00', 18, 1),
(4, 1, '16:30:00', '22:00:00', 21, 1),
(5, 1, '22:00:00', '00:00:00', 20, 1),
(6, 2, '00:00:00', '06:00:00', 20, 1),
(7, 2, '06:30:00', '08:00:00', 21, 1),
(8, 2, '08:00:00', '16:30:00', 18, 1),
(9, 2, '16:30:00', '22:00:00', 21, 1),
(10, 2, '22:00:00', '00:00:00', 20, 1),
(11, 3, '00:00:00', '06:00:00', 20, 1),
(12, 3, '06:30:00', '08:00:00', 21, 1),
(13, 3, '08:00:00', '16:30:00', 18, 1),
(14, 3, '16:30:00', '22:00:00', 21, 1),
(15, 3, '22:00:00', '00:00:00', 20, 1),
(16, 4, '00:00:00', '06:00:00', 20, 1),
(17, 4, '06:30:00', '08:00:00', 21, 1),
(18, 4, '08:00:00', '16:30:00', 18, 1),
(19, 4, '16:30:00', '22:00:00', 21, 1),
(20, 4, '22:00:00', '00:00:00', 20, 1),
(21, 5, '00:00:00', '06:00:00', 20, 1),
(22, 5, '06:30:00', '08:00:00', 21, 1),
(23, 5, '08:00:00', '16:30:00', 18, 1),
(24, 5, '16:30:00', '22:00:00', 21, 1),
(25, 5, '22:00:00', '00:00:00', 20, 1),
(26, 6, '00:00:00', '06:00:00', 20, 1),
(27, 6, '07:00:00', '22:00:00', 21, 1),
(28, 6, '22:00:00', '00:00:00', 20, 1),
(29, 7, '00:00:00', '06:00:00', 20, 1),
(30, 7, '07:00:00', '22:00:00', 21, 1),
(31, 7, '22:00:00', '00:00:00', 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `value` varchar(255) DEFAULT NULL,
  `key` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `temperatures`
--

CREATE TABLE `temperatures` (
  `id` int(10) UNSIGNED NOT NULL,
  `value` float DEFAULT NULL,
  `createdAt` datetime DEFAULT NULL,
  `device_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `temperatures`
--
ALTER TABLE `temperatures`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `devices`
--
ALTER TABLE `devices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `temperatures`
--
ALTER TABLE `temperatures`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
